---
title: "Min første dag"
lastmod: 1972-02-28
---